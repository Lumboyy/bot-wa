// controls //
global.owner = ['6281937707120']
global.ownername = "xin"
global.connect = true // ubah ke false klo mau connect lewat qrcode 
global.antilink = false
global.autotyping = false
// hosting //
      // panel //
global.domain = "-" // jan pke / di akhiran domain
global.apikey = "-" 
global.capikey = "-"
global.eggsnya = '15' 
global.location3 = '1'

// api digital ocean
global.token_do = "-"

 // panel server 2 //
global.domain2 = "-"
global.apikey2 = "-"
global.capikey2 = "-"
global.egg2 = '15' 
global.loc2 = '1' 

 // subdomain //
global.subdomain = {
"reseller-panel.me": {
"zone": "b1efab0f1d81a0137eb5d62e00d6e3f8",
"apitoken": "W3b66ootKk1pERNSB6DbyW383OXRCoakw3PQExyS"
},
"market-panel.site": {
"zone": "d06bf5450ae51612a400bab1c4450283",
"apitoken": "kmb6AkpJ6XvHMzw2m0KbYKZOycIURNYMPA7Wm0BE",
},
"admin-panel.tech": {
"zone": "305d4757160a88486d3780785c7c9887",
"apitoken": "UH-aDtxu5Mm9oU8khMd5ZVg22f7nhnSkCORBn8zP",
},
"kang-panel.tech": {
"zone": "28baf36eb9ced4be271bdb6ea3320f41",
"apitoken": "MBiKuyoS0e0zJc8LKUjSXyLmgAf1IV9u86FJmVny",
},
"web-cabul.me": {
"zone": "4b24636040f0f2d799a8a1aaea568e57",
"apitoken": "OvRX-DghNjcPF9rlKElGCLIsPvv3Nd3khuDAUZ3q",
},

"king-hosting.live": {
"zone": "2e6eb183148e0ef9add390af271a8bb2",
"apitoken": "kcnnE1sESybx-P_nLkkiKtfZFqGhRmwFg9wL0cf6",
},
"tokopanel.software": {
"zone": "cc9638d4c289130ba070484625e6aefa",
"apitoken": "bcAP5z3gHvmQTlQ59qNB9BWmf0JiGt0C99FU6SXs",
},
"pannel-private.me": {
"zone": "71ad41d3c25085bd7b8a1135632c7c63",
"apitoken": "HfGKPUu1KrOVc3q51nkoJYZFQvIpA-AFOP-t6SNZ",
},
"hitam.systems": {
"zone": "cfaba3ef0065acc82facc17f1b79d50b",
"apitoken": "4o3tZAc5jOzA00joKpLYhG_616qCJxNLGlhawMEY",
},
"panel-run-bot.engineer": {
"zone": "678298eaac2e2a0dea25f693310ec6e0",
"apitoken": "8UmNiZZqEIAqWbM7XlcZofyvhc70NMs2_gXmmkug",
},
"uchiha.tech": {
"zone": "1b09e81ec29d760ff33e476a084de6ed",
"apitoken": "nzLwv-2uzMt3Ihsd5MVV2aLJ9EoovxrVK7Y4b2To",
},
"buyer-vps.site": {
"zone": "354e1c784bed5a8d93f458ec1ff86f35",
"apitoken": "rzOLIO1c-Me1X0owStLFUZ0ggfs_cxHDab2A7krF",
},
"arzanoffc.online": {
"zone": "43ca801f5c6a73a77da5f0243f4f8c1d",
"apitoken": "RZQft_gJGOJDskx6L6SxREJCvOKw0hclLjHUCNLS",
},
"hexaneuro.biz.id": {
"zone": "16273869fda58585fc435e4582a5ff56",
"apitoken": "y4wV0um-bvrVTvFVPrNrGEi590bPowvosRyNiGMn"
 },   
"mypanel.tech": {
"zone": "9c5460deca7c84273b46f2f047783636",
"apitoken": "0IBfmlUlCkYqoFPWYaqCmqI3_vWxkrFNbxrQjzX2"
}, 
"kedai-panel.me": {
"zone": "3ab91ea96368234719c9de7d260742e2",
"apitoken": "O22A19W7trZZ52bAXtF77aUVdGDdAk8PjQqwM7qv"
}, 
"control-pannel.site": {
"zone": "20c517d7dcc25d9cf516f5c4cf2d21ba",
"apitoken": "mAA84Qs4nJvLTaup0HTGrpVbgaSk-4vfUrcdHgCH"
}, 
"mypanelstore.xyz": {
"zone": "72f7362d7686d9158a8e389851fc379c", 
"apitoken": "V2y-I2o1s5E1tdCPpUSnT4FokV6WuxEUC2FqqVIX"
}
}

// pays //
global.dana = "XXXX"
global.gopay = "XXXX"
global.ovo = "XXXX"
global.qris = "https://files.catbox.moe/5dfafw.jpg"

// msg //
global.mess = {
"ketua": " ⇝ Access Denied 🖕🏼\nKhusus Owner\nBeli Script Di Wa.me/6281937707120\nAtau Di\nt.me/htmlxin\n© Xin",
"prem": "⇝ Access Denied 🖕🏼\nBeli Akses Premium Di Wa.me/6281937707120\nAtau Di\nt.me/htmlxin\n© Xin"
}

// misc //
global.versionofscript = "1.8"
global.url = "https://files.catbox.moe/i7jxyz.jpg" // buat banner
global.urlbanner = "https://files.catbox.moe/zay0u6.jpg" // buat banner 2
global.url2 = "https://t.me/htmlxin" // isi url bebas buat reply
global.packname = "jel?" // sticker
global.author = "x-trash" // sticker
global.group = "https://chat.whatsapp.com/Kh6HSBqWdb423TgbvNTiGo" // isi group bebas lu
global.idCH = "120363333509194874@newsletter"
global.xchannel = {
	jid: '120363333509194874@newsletter'
	}
	